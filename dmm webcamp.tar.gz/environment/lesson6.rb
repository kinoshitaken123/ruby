total_price = 100

if total_price >100
  puts "みかんを購入。所持金に余りあり。"
elseif total_price = 100
  puts "みかんを購入。所持金は0円。"
else
  puts "みかんを購入することができません。"
end
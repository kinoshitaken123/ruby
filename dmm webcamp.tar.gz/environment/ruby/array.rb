names =["Git","HTML","CSS"]
puts names [1]
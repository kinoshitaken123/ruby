webcamp = "プログラミング学習"
puts webcamp

webcamp = "オンラインプログラミング学習"  # この行を追加
puts webcamp  # この行を追加
name ="kinoshita"
puts name
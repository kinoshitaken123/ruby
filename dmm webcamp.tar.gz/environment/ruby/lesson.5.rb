subjects = ["国語","算数","理科","社会"]
puts subjects[2]
puts 5
puts "5"
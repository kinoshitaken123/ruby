apple ="Yamanasi"

if apple == "Aomori"
  puts "このリンゴは青森県産です"
elsif apple == "Nagano"
  puts "このリンゴは青森県さんではなく、長野産です"
else
  puts "このリンゴは青森県産でもなく長野産のものではありません"
end
hand ="グー"
if hand == "グー"
  puts "出したてはグーです"
end

if hand != "チョキ"
  puts "出した手はチョキではありません"
end

if (hand == "グー")||(handb == "パー")
  puts "出した手はグーまたはパーです"
end
class List < ApplicationRecord
   attachment :image
end
